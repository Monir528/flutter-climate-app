package com.example.clime

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
